import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatNumber(num: number): string {
  if (num >= 10000000) return `${(num / 10000000).toFixed(1)}Cr+`
  if (num >= 100000) return `${(num / 100000).toFixed(1)}L+`
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K+`
  return num.toString()
}

export function scrollToSection(id: string) {
  const element = document.getElementById(id)
  if (element) {
    element.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }
}

export function slugify(text: string): string {
  return text.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '')
}

export const siteConfig = {
  name: 'Amber Labs',
  tagline: 'Engineer the Future of Your Business',
  description: 'Amber Labs is a cutting-edge digital innovation lab in Jaipur, Rajasthan. We build premium websites, AI automation systems, and growth engines that scale businesses beyond imagination.',
  url: 'https://amberlabs.in',
  ogImage: 'https://amberlabs.in/og.jpg',
  phone: '+91 9509672731',
  email: 'devanshchotrani16@gmail.com',
  address: 'Jaipur, Rajasthan, India',
  social: {
    instagram: '',  // Add your Instagram
    linkedin: 'https://www.linkedin.com/in/devansh-chotrani/',
    twitter: '',    // Add your Twitter/X
    youtube: '',    // Add your YouTube
    github: 'https://github.com/devanxsh',
    whatsapp: 'https://wa.me/919509672731',
  },
}

export const founderInfo = {
  name: 'Devansh Chotrani',
  role: 'Founder & Lead Architect',
  bio: 'Visionary technologist and digital architect. Devansh founded Amber Labs with a singular mission — to bridge the gap between bleeding-edge technology and real business growth. With deep expertise in AI automation, web engineering, and conversion optimization, he leads a team that builds digital products that don\'t just look good — they deliver measurable, scalable results.',
  vision: 'To become India\'s most trusted technology innovation lab — where ambitious businesses come to build their digital future.',
  mission: 'Engineer elegant, high-performance digital solutions that automate growth, eliminate complexity, and create lasting competitive advantages for every client.',
  values: [
    'Craft over Commodity — We don\'t do template work',
    'Data over Opinion — Every decision is measured',
    'Speed as a Feature — Performance is non-negotiable',
    'Simplicity is Genius — We make complex look effortless',
  ],
}

export const futureVision = {
  headline: 'What We\'re Building Next',
  description: 'Amber Labs isn\'t just a service provider — we\'re building the future of business technology. Here\'s what\'s on our roadmap.',
  pillars: [
    {
      title: 'AI-Native Agency OS',
      description: 'A proprietary operating system that automates entire marketing workflows — from lead gen to client reporting — powered by custom-trained AI agents.',
      icon: 'Brain',
      timeline: 'Q3 2025',
      status: 'In Development',
    },
    {
      title: 'Amber Commerce Suite',
      description: 'A complete D2C brand-building platform with AI-powered product photography, automated ad creation, dynamic pricing engines, and predictive inventory management.',
      icon: 'ShoppingCart',
      timeline: 'Q4 2025',
      status: 'On Roadmap',
    },
    {
      title: 'Founders Dashboard',
      description: 'Real-time business intelligence dashboard for founders — unifying marketing, sales, support, and financial data into one beautiful, actionable interface.',
      icon: 'BarChart3',
      timeline: 'Q1 2026',
      status: 'Design Phase',
    },
    {
      title: 'Amber AI Chat Platform',
      description: 'Next-gen conversational AI platform with voice support, multilingual capabilities, and deep CRM integrations — built specifically for Indian businesses.',
      icon: 'Bot',
      timeline: 'Q2 2026',
      status: 'Research',
    },
    {
      title: 'No-Code Growth Engine',
      description: 'Drag-and-drop marketing automation builder that lets business owners create sophisticated multi-channel campaigns without writing a single line of code.',
      icon: 'Zap',
      timeline: 'Q3 2026',
      status: 'Concept',
    },
    {
      title: 'Amber Capital',
      description: 'A venture-building arm that identifies high-potential startups and invests technology, design, and marketing equity in exchange for partnership — not just cash.',
      icon: 'Rocket',
      timeline: '2027',
      status: 'Vision',
    },
  ],
}

export const services = [
  {
    id: 'seo',
    title: 'Search Engine Optimization',
    description: 'Dominate Google search results with data-driven SEO strategies that drive organic traffic and qualified leads.',
    fullDescription: 'Our SEO process begins with a comprehensive audit of your current online presence, competitor analysis, and keyword research. We then implement a custom strategy combining technical SEO, on-page optimization, content marketing, and authoritative link building. Monthly reports track rankings, traffic, and conversions with transparent dashboards.',
    icon: 'Search',
    features: ['Technical SEO Audit', 'Keyword Research & Strategy', 'On-Page Optimization', 'Content Marketing', 'Link Building', 'Local SEO', 'SEO Analytics & Reporting'],
    metrics: { avgTrafficGrowth: '340%', avgLeadGrowth: '280%', avgTimeframe: '3-6 months' },
  },
  {
    id: 'google-ads',
    title: 'Google Ads Management',
    description: 'Maximize ROAS with precision-targeted Google Ads campaigns optimized by AI and managed by certified experts.',
    fullDescription: 'We build and manage high-converting Google Ads campaigns across Search, Display, Shopping, and Performance Max. Our AI-powered optimization engine adjusts bids, keywords, and ad copy in real-time to maximize your return on ad spend while scaling your campaigns profitably.',
    icon: 'BarChart3',
    features: ['Search Campaigns', 'Display Advertising', 'Shopping Ads', 'Performance Max', 'Remarketing', 'Keyword Strategy', 'A/B Ad Testing'],
    metrics: { avgTrafficGrowth: '520%', avgLeadGrowth: '410%', avgTimeframe: '1-3 months' },
  },
  {
    id: 'meta-ads',
    title: 'Meta Ads Management',
    description: 'Convert audiences into customers with Facebook & Instagram ad campaigns engineered for maximum engagement and conversions.',
    fullDescription: 'Our Meta advertising team creates scroll-stopping creatives and laser-targeted campaigns across Facebook, Instagram, and Messenger. We leverage custom audiences, lookalike modeling, and advanced pixel tracking to drive measurable results.',
    icon: 'Instagram',
    features: ['Facebook Ads', 'Instagram Ads', 'Audience Targeting', 'Creative Strategy', 'Retargeting', 'Lookalike Audiences', 'Conversion Optimization'],
    metrics: { avgTrafficGrowth: '450%', avgLeadGrowth: '380%', avgTimeframe: '1-3 months' },
  },
  {
    id: 'web-dev',
    title: 'Website Design & Development',
    description: 'High-performance websites that convert visitors into customers with modern design, lightning-fast speeds, and seamless UX.',
    fullDescription: 'We design and develop premium websites using cutting-edge technology including Next.js, Three.js, and Framer Motion. Every site is built for speed, SEO, and conversions from the ground up — with stunning animations, intuitive navigation, and optimized user flows.',
    icon: 'Code2',
    features: ['Custom Web Design', 'Next.js Development', 'E-commerce Solutions', 'Landing Pages', 'UI/UX Design', 'SEO Optimization', 'Performance Tuning'],
    metrics: { avgTrafficGrowth: '200%', avgLeadGrowth: '310%', avgTimeframe: '4-8 weeks' },
  },
  {
    id: 'social-media',
    title: 'Social Media Management',
    description: 'Build a powerful brand presence across platforms with content that engages, converts, and drives real business growth.',
    fullDescription: 'Our social media team manages your entire brand presence across Instagram, LinkedIn, Facebook, and Twitter. We create platform-specific content strategies, produce professional-grade visuals and videos, engage with your community, and run targeted growth campaigns.',
    icon: 'Users',
    features: ['Content Strategy', 'Graphic Design', 'Video Production', 'Community Management', 'Growth Campaigns', 'Analytics Reporting', 'Influencer Marketing'],
    metrics: { avgTrafficGrowth: '290%', avgLeadGrowth: '250%', avgTimeframe: '2-4 months' },
  },
  {
    id: 'branding',
    title: 'Branding & Creative Design',
    description: 'Distinctive brand identities that command attention, build trust, and create lasting impressions in competitive markets.',
    fullDescription: 'We craft comprehensive brand identities that communicate your unique value proposition. From logo design and color palettes to brand guidelines and marketing collateral, every element is designed to position you as a leader in your industry.',
    icon: 'Palette',
    features: ['Brand Strategy', 'Logo Design', 'Visual Identity', 'Brand Guidelines', 'Packaging Design', 'Marketing Collateral', 'Brand Voice Development'],
    metrics: { avgTrafficGrowth: '180%', avgLeadGrowth: '220%', avgTimeframe: '4-6 weeks' },
  },
  {
    id: 'ai-automation',
    title: 'AI Automation',
    description: 'Transform your operations with custom AI chatbots, WhatsApp automation, and intelligent lead qualification systems.',
    fullDescription: 'We build AI-powered automation systems that handle customer inquiries 24/7, qualify leads automatically, send personalized follow-ups, book appointments, and integrate seamlessly with your existing CRM and business tools.',
    icon: 'Bot',
    features: ['AI Chatbots', 'WhatsApp Automation', 'Lead Qualification', 'CRM Integration', 'Follow-Up Automation', 'Appointment Booking', 'Analytics Dashboard'],
    metrics: { avgTrafficGrowth: '160%', avgLeadGrowth: '540%', avgTimeframe: '2-4 weeks' },
  },
  {
    id: 'lead-gen',
    title: 'Lead Generation Systems',
    description: 'Multi-channel lead generation systems that fill your sales pipeline with qualified, high-intent prospects on autopilot.',
    fullDescription: 'Our lead generation systems combine paid advertising, SEO, content marketing, social selling, and AI automation to create a predictable flow of qualified leads. We design end-to-end funnels optimized for your specific industry and target audience.',
    icon: 'Target',
    features: ['Lead Funnel Design', 'Multi-Channel Outreach', 'Landing Page Optimization', 'Lead Scoring', 'CRM Integration', 'Email Sequences', 'Analytics & Tracking'],
    metrics: { avgTrafficGrowth: '320%', avgLeadGrowth: '450%', avgTimeframe: '1-3 months' },
  },
]

export const caseStudies = [
  {
    id: 'luxury-realty',
    businessType: 'Luxury Real Estate',
    client: 'Jaipur Estates',
    challenge: 'Jaipur Estates, a premium real estate developer, struggled with low online visibility and high cost-per-lead despite a strong offline reputation. Their website was outdated, and they had no systematic digital marketing strategy.',
    strategy: 'We built a complete digital ecosystem: a stunning new website with virtual property tours, Google Ads targeting high-net-worth buyers, Meta Ads with lifestyle imagery, SEO for luxury real estate keywords, and an AI-powered WhatsApp lead qualification system.',
    results: { trafficGrowth: '580%', leadGrowth: '720%', revenueGrowth: '340%', costPerLead: '-65%' },
    metrics: [
      { label: 'Monthly Organic Traffic', before: '1,200', after: '8,400' },
      { label: 'Qualified Leads/Month', before: '15', after: '120' },
      { label: 'Cost Per Lead', before: '₹4,500', after: '₹1,575' },
      { label: 'Revenue/Month', before: '₹45L', after: '₹2.1Cr' },
    ],
    image: '/images/case-study-1.jpg',
    tags: ['Real Estate', 'SEO', 'Google Ads', 'AI Automation'],
  },
  {
    id: 'edtech-platform',
    businessType: 'EdTech Platform',
    client: 'LearnPro India',
    challenge: 'LearnPro India, a growing online education platform, faced fierce competition from established players. Their ad spend was inefficient with a CAC of ₹2,800 and they struggled to scale enrollment predictably.',
    strategy: 'We overhauled their marketing with a data-driven approach: SEO for competitive course keywords, retargeting campaigns on Meta and Google, automated email sequences for leads, and an AI chatbot handling 70% of pre-enrollment inquiries.',
    results: { trafficGrowth: '420%', leadGrowth: '560%', revenueGrowth: '410%', costPerLead: '-58%' },
    metrics: [
      { label: 'Monthly Website Traffic', before: '8,000', after: '42,000' },
      { label: 'Course Enrollments', before: '45', after: '280' },
      { label: 'Customer Acquisition Cost', before: '₹2,800', after: '₹1,176' },
      { label: 'Monthly Revenue', before: '₹12L', after: '₹62L' },
    ],
    image: '/images/case-study-2.jpg',
    tags: ['EdTech', 'SEO', 'Meta Ads', 'AI Chatbots'],
  },
  {
    id: 'd2c-brand',
    businessType: 'D2C E-Commerce',
    client: 'Artisan Home Decor',
    challenge: 'This Jaipur-based home decor brand had beautiful handcrafted products but zero online traction. Their Shopify store averaged only 200 visitors/day with a 0.5% conversion rate and ₹5,000 daily ad spend yielding negative ROAS.',
    strategy: 'Complete digital transformation: redesigned store with premium UX, implemented Performance Max campaigns, Instagram Shopping integration, influencer partnerships, email automation sequences, and retargeting funnels.',
    results: { trafficGrowth: '890%', leadGrowth: '950%', revenueGrowth: '670%', costPerLead: '-72%' },
    metrics: [
      { label: 'Daily Website Traffic', before: '200', after: '1,980' },
      { label: 'Conversion Rate', before: '0.5%', after: '3.8%' },
      { label: 'Monthly Revenue', before: '₹3L', after: '₹23L' },
      { label: 'ROAS', before: '0.8x', after: '5.2x' },
    ],
    image: '/images/case-study-3.jpg',
    tags: ['E-Commerce', 'Shopify', 'Google Ads', 'Social Media'],
  },
  {
    id: 'healthcare-clinic',
    businessType: 'Healthcare',
    client: 'Aarogya Multispeciality',
    challenge: 'A premium multispeciality clinic in Jaipur wanted to attract more patients but had zero digital presence. Competing clinics dominated search results and local SEO rankings.',
    strategy: 'Local SEO dominance strategy with Google Business Profile optimization, localized content marketing, Google Ads for high-intent medical queries, reputation management, and a patient-friendly website with online booking integration.',
    results: { trafficGrowth: '340%', leadGrowth: '480%', revenueGrowth: '290%', costPerLead: '-55%' },
    metrics: [
      { label: 'Monthly Patient Inquiries', before: '45', after: '260' },
      { label: 'Google Maps Visibility', before: 'Page 4', after: '#1 (Top 3)' },
      { label: 'Cost Per Patient', before: '₹1,200', after: '₹540' },
      { label: 'Monthly Revenue', before: '₹18L', after: '₹70L' },
    ],
    image: '/images/case-study-4.jpg',
    tags: ['Healthcare', 'Local SEO', 'Google Ads', 'Web Development'],
  },
]

export const testimonials = [
  {
    id: 1,
    name: 'Rajesh Sharma',
    role: 'CEO, Jaipur Estates',
    content: 'Amber Labs transformed our entire business. Our website traffic increased by 580% and we went from 15 leads a month to 120 qualified inquiries. The AI WhatsApp automation alone saved us countless hours. They are not just an agency — they are growth partners.',
    rating: 5, company: 'Jaipur Estates', featured: true,
  },
  {
    id: 2,
    name: 'Priya Mehta',
    role: 'Founder, LearnPro India',
    content: 'We tried three other agencies before Amber Labs. The difference is night and day. They deeply understood our market, built a strategy that worked, and delivered results that exceeded our projections. Our enrollments grew 6x in just 4 months.',
    rating: 5, company: 'LearnPro India', featured: true,
  },
  {
    id: 3,
    name: 'Vikram Singh',
    role: 'Director, Artisan Home Decor',
    content: 'Going from ₹3L to ₹23L in monthly revenue in 5 months is incredible. But what impressed me most is their attention to detail — every ad creative, every landing page, every email feels premium. They genuinely care about quality.',
    rating: 5, company: 'Artisan Home Decor', featured: true,
  },
  {
    id: 4,
    name: 'Dr. Ananya Gupta',
    role: 'Medical Director, Aarogya Clinic',
    content: 'Amber Labs put us on the map. We went from being invisible online to ranking #1 for 20+ medical keywords. Our patient inquiries grew 5x and our cost per patient dropped by 55%. Absolutely outstanding work.',
    rating: 5, company: 'Aarogya Multispeciality', featured: false,
  },
  {
    id: 5,
    name: 'Amit Khanna',
    role: 'CEO, GreenLeaf Restaurants',
    content: 'The ROI we have seen with Amber Labs is unmatched. Our Google Ads campaigns went from losing money to delivering a 4.8x ROAS. Their reporting is transparent, their team is responsive, and their expertise is world-class.',
    rating: 5, company: 'GreenLeaf Restaurants', featured: false,
  },
]

export const industries = [
  { id: 'real-estate', name: 'Real Estate', icon: 'Building2', description: 'Generate qualified leads for properties with hyper-targeted campaigns.' },
  { id: 'healthcare', name: 'Healthcare', icon: 'Heart', description: 'Attract more patients with compliant, empathetic digital marketing.' },
  { id: 'education', name: 'Education', icon: 'GraduationCap', description: 'Drive enrollments with SEO & ads optimized for education keywords.' },
  { id: 'restaurants', name: 'Restaurants', icon: 'UtensilsCrossed', description: 'Fill tables with local search, ads, and mouth-watering content.' },
  { id: 'ecommerce', name: 'E-Commerce', icon: 'ShoppingCart', description: 'Scale revenue with Performance Max, social commerce & email.' },
  { id: 'manufacturing', name: 'Manufacturing', icon: 'Factory', description: 'B2B lead generation through LinkedIn, SEO & industry content.' },
  { id: 'startups', name: 'Startups', icon: 'Rocket', description: 'Growth-stage marketing that scales as fast as your startup.' },
  { id: 'local-business', name: 'Local Businesses', icon: 'Store', description: 'Dominate your neighborhood with precision local marketing.' },
]

export const faqs = [
  { q: 'How much should I budget for digital marketing?', a: 'For businesses in Jaipur, we recommend starting at ₹30,000-₹50,000/month for a comprehensive strategy. Mid-market businesses typically invest ₹1-3L/month. We always design campaigns that deliver positive ROI from month one and scale based on performance.' },
  { q: 'How long until I see results?', a: 'Paid advertising (Google & Meta Ads) typically shows results within 2-3 weeks. SEO takes 3-6 months to build momentum. We set clear benchmarks and provide monthly reports so you always know exactly what\'s working.' },
  { q: 'Do you work with businesses outside Jaipur?', a: 'Absolutely! While we\'re based in Jaipur, we work with clients across India and internationally. Our entire workflow is designed for seamless remote collaboration with weekly calls, real-time dashboards, and transparent communication.' },
  { q: 'What makes Amber Labs different from other agencies?', a: 'We combine premium design thinking with data-driven marketing and AI automation. Most agencies offer one or the other — we deliver a complete technology ecosystem. Plus, we assign a dedicated account manager and provide transparent reporting with no hidden fees.' },
  { q: 'Do you offer month-to-month contracts?', a: 'Yes! We offer flexible engagement models. Most clients start with a 3-month commitment to build momentum, then switch to month-to-month. We\'re confident in our results — if you\'re not happy, you can leave anytime.' },
  { q: 'Which industries do you specialize in?', a: 'We have deep expertise in real estate, healthcare, education, e-commerce, restaurants, manufacturing, and startups. Our team includes specialists who understand the unique dynamics of each industry.' },
  { q: 'Can you fix my existing campaigns?', a: 'Yes — that\'s one of our specialties. We conduct a comprehensive audit of your current marketing, identify leaks and opportunities, and implement a systematic optimization plan. Most clients see 40-60% improvement within 30 days.' },
  { q: 'Do you provide local SEO for Jaipur businesses?', a: 'Yes! Local SEO is one of our core strengths. We help Jaipur businesses dominate Google Maps, local pack results, and city-specific search queries. Our local SEO package includes GBP optimization, local citations, review management, and geo-targeted content.' },
]