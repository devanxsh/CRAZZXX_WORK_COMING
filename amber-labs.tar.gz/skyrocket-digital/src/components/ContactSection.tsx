'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Send, Phone, Mail, MapPin, Calendar } from 'lucide-react'
import { siteConfig } from '@/lib/utils'

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '', business: '', phone: '', email: '', industry: '',
    monthlyRevenue: '', marketingBudget: '', services: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Lead:', formData)
    setSubmitted(true)
  }

  return (
    <section id="contact" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/3 rounded-full blur-[200px]" />
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-strong mb-6"
          >
            <span className="w-2 h-2 rounded-full bg-success" />
            <span className="text-sm text-text-secondary">Let&apos;s Talk</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6"
          >
            Ready to{' '}
            <span className="text-gradient">SkyRocket</span>{' '}
            Your Growth?
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-text-secondary text-lg max-w-2xl mx-auto"
          >
            Book a free strategy call and discover how we can transform your business.
          </motion.p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8 max-w-5xl mx-auto">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2 space-y-4"
          >
            {[
              { icon: Phone, label: 'Call Us', value: siteConfig.phone, href: `tel:${siteConfig.phone.replace(/\s/g, '')}` },
              { icon: Mail, label: 'Email', value: siteConfig.email, href: `mailto:${siteConfig.email}` },
              { icon: MapPin, label: 'Visit Us', value: siteConfig.address, href: '#' },
            ].map((item) => (
              <a key={item.label} href={item.href} className="block glass rounded-xl p-4 flex items-center gap-4 hover:bg-white/[0.04] transition-colors">
                <div className="p-3 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10">
                  <item.icon className="w-5 h-5 text-primary-light" />
                </div>
                <div>
                  <div className="text-xs text-text-muted">{item.label}</div>
                  <div className="text-sm font-medium">{item.value}</div>
                </div>
              </a>
            ))}

            <a
              href="https://wa.me/919509672731"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 glass-strong rounded-xl text-sm font-medium hover:bg-white/[0.06] transition-colors mt-6"
            >
              <Calendar className="w-4 h-4" />
              Book a Free Strategy Call on WhatsApp
            </a>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-3"
          >
            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass rounded-2xl p-8 text-center"
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-success/20 to-accent/20 flex items-center justify-center mx-auto mb-4">
                  <Send className="w-6 h-6 text-success" />
                </div>
                <h3 className="text-xl font-bold mb-2">Thank You!</h3>
                <p className="text-text-secondary">We&apos;ll review your information and get back to you within 24 hours.</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-text-muted mb-1.5 block">Full Name *</label>
                    <input required className="input-premium w-full" placeholder="Your name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-xs text-text-muted mb-1.5 block">Business Name *</label>
                    <input required className="input-premium w-full" placeholder="Your business" value={formData.business} onChange={(e) => setFormData({ ...formData, business: e.target.value })} />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-text-muted mb-1.5 block">Phone Number *</label>
                    <input required type="tel" className="input-premium w-full" placeholder="+91 98765 43210" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-xs text-text-muted mb-1.5 block">Email *</label>
                    <input required type="email" className="input-premium w-full" placeholder="you@company.com" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-text-muted mb-1.5 block">Industry</label>
                    <select className="input-premium w-full" value={formData.industry} onChange={(e) => setFormData({ ...formData, industry: e.target.value })}>
                      <option value="">Select industry</option>
                      <option>Real Estate</option><option>Healthcare</option><option>Education</option>
                      <option>E-Commerce</option><option>Restaurant</option><option>Manufacturing</option>
                      <option>Startup</option><option>Local Business</option><option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-text-muted mb-1.5 block">Monthly Revenue</label>
                    <select className="input-premium w-full" value={formData.monthlyRevenue} onChange={(e) => setFormData({ ...formData, monthlyRevenue: e.target.value })}>
                      <option value="">Select range</option>
                      <option>Under ₹1L</option><option>₹1L - ₹5L</option><option>₹5L - ₹20L</option>
                      <option>₹20L - ₹1Cr</option><option>₹1Cr+</option><option>Prefer not to say</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-text-muted mb-1.5 block">Marketing Budget (Monthly)</label>
                  <select className="input-premium w-full" value={formData.marketingBudget} onChange={(e) => setFormData({ ...formData, marketingBudget: e.target.value })}>
                    <option value="">Select range</option>
                    <option>Under ₹30K</option><option>₹30K - ₹1L</option><option>₹1L - ₹3L</option>
                    <option>₹3L - ₹10L</option><option>₹10L+</option><option>Not sure yet</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-text-muted mb-1.5 block">Services Required</label>
                  <select className="input-premium w-full" value={formData.services} onChange={(e) => setFormData({ ...formData, services: e.target.value })}>
                    <option value="">Select service</option>
                    <option>SEO</option><option>Google Ads</option><option>Meta Ads</option>
                    <option>Website Design</option><option>Social Media</option><option>AI Automation</option>
                    <option>Lead Generation</option><option>Branding</option><option>Full Strategy</option>
                  </select>
                </div>
                <button type="submit" className="w-full py-3.5 bg-gradient-to-r from-primary to-accent text-white font-medium rounded-xl hover:shadow-lg hover:shadow-primary/25 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2">
                  <Send className="w-4 h-4" />
                  Send Inquiry
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  )
}