'use client'

import { useRef, useState } from 'react'
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion'
import {
  Search, BarChart3, Instagram, Code2, Users, Palette, Bot, Target,
  ArrowRight, Check, X, ChevronRight
} from 'lucide-react'
import { services } from '@/lib/utils'

const iconMap: Record<string, React.ReactNode> = {
  Search: <Search className="w-6 h-6" />,
  BarChart3: <BarChart3 className="w-6 h-6" />,
  Instagram: <Instagram className="w-6 h-6" />,
  Code2: <Code2 className="w-6 h-6" />,
  Users: <Users className="w-6 h-6" />,
  Palette: <Palette className="w-6 h-6" />,
  Bot: <Bot className="w-6 h-6" />,
  Target: <Target className="w-6 h-6" />,
}

function ServiceModal({ service, onClose }: { service: typeof services[0]; onClose: () => void }) {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          onClick={(e) => e.stopPropagation()}
          className="relative max-w-2xl w-full glass-strong rounded-2xl p-8 max-h-[85vh] overflow-y-auto"
        >
          <button onClick={onClose} className="absolute top-4 right-4 p-2 text-text-muted hover:text-text rounded-lg hover:bg-white/5 transition-colors">
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 text-primary-light">
              {iconMap[service.icon]}
            </div>
            <div>
              <h3 className="text-2xl font-bold">{service.title}</h3>
              <p className="text-accent-light text-sm font-medium">Avg. Lead Growth: {service.metrics.avgLeadGrowth}</p>
            </div>
          </div>

          <p className="text-text-secondary mb-6 leading-relaxed">{service.fullDescription}</p>

          <div className="mb-6">
            <h4 className="text-sm font-semibold text-text mb-3 uppercase tracking-wider">What's Included</h4>
            <div className="grid sm:grid-cols-2 gap-2">
              {service.features.map((f) => (
                <div key={f} className="flex items-center gap-2 text-sm text-text-secondary">
                  <Check className="w-4 h-4 text-primary-light flex-shrink-0" />
                  <span>{f}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass rounded-xl p-4 grid grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="text-lg font-bold text-gradient">{service.metrics.avgTrafficGrowth}</div>
              <div className="text-xs text-text-muted">Traffic Growth</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-gradient">{service.metrics.avgLeadGrowth}</div>
              <div className="text-xs text-text-muted">Lead Growth</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-gradient">{service.metrics.avgTimeframe}</div>
              <div className="text-xs text-text-muted">Timeframe</div>
            </div>
          </div>

          <button
            onClick={() => { onClose(); document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }) }}
            className="w-full py-3 bg-gradient-to-r from-primary to-accent text-white font-medium rounded-xl hover:shadow-lg hover:shadow-primary/25 transition-all"
          >
            Get Started With {service.title}
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

export default function ServicesSection() {
  const [selectedService, setSelectedService] = useState<typeof services[0] | null>(null)
  const sectionRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  })
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0])
  const y = useTransform(scrollYProgress, [0, 0.2], [100, 0])

  return (
    <section id="services" ref={sectionRef} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-20" />
      <div className="absolute top-1/3 right-0 w-96 h-96 bg-primary/3 rounded-full blur-[100px]" />
      <div className="absolute bottom-1/3 left-0 w-96 h-96 bg-accent/3 rounded-full blur-[100px]" />

      <motion.div style={{ opacity, y }} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-strong mb-6"
          >
            <span className="w-2 h-2 rounded-full bg-primary" />
            <span className="text-sm text-text-secondary">Our Services</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6"
          >
            <span className="text-gradient">Full-Service</span>{' '}
            <span className="text-text">Digital Marketing</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-text-secondary text-lg max-w-3xl mx-auto"
          >
            From SEO to AI automation, we offer every service you need to dominate your market and scale your revenue.
          </motion.p>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {services.map((service, i) => (
            <motion.button
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              onClick={() => setSelectedService(service)}
              className="group relative text-left glass rounded-2xl p-6 transition-all duration-500 hover:bg-white/[0.04] hover:shadow-xl hover:shadow-primary/5 overflow-hidden"
            >
              {/* Hover Glow */}
              <div className="absolute -inset-2 bg-gradient-to-r from-primary/10 to-accent/10 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl" />

              {/* Icon */}
              <div className="relative mb-4 p-3 rounded-xl bg-gradient-to-br from-primary/10 to-accent/10 w-fit group-hover:scale-110 transition-transform duration-300">
                <div className="text-primary-light group-hover:text-accent-light transition-colors">
                  {iconMap[service.icon]}
                </div>
              </div>

              {/* Content */}
              <h3 className="relative text-lg font-semibold mb-2 group-hover:text-gradient transition-all">{service.title}</h3>
              <p className="relative text-sm text-text-secondary leading-relaxed mb-4">{service.description}</p>

              {/* Metrics Preview */}
              <div className="relative flex items-center gap-3 text-xs text-text-muted">
                <span className="text-primary-light font-medium">+{service.metrics.avgLeadGrowth}</span>
                <span className="w-1 h-1 rounded-full bg-border" />
                <span>{service.metrics.avgTimeframe}</span>
              </div>

              {/* Arrow */}
              <div className="relative mt-4 flex items-center gap-1 text-sm text-primary-light opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Learn more</span>
                <ChevronRight className="w-4 h-4" />
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Modal */}
      {selectedService && (
        <ServiceModal service={selectedService} onClose={() => setSelectedService(null)} />
      )}
    </section>
  )
}