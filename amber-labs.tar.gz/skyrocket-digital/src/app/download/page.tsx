'use client'

import { motion } from 'framer-motion'
import { Download, ArrowLeft, Sparkles } from 'lucide-react'

export default function DownloadPage() {
  return (
    <div className="min-h-screen bg-surface flex flex-col items-center justify-center p-4">
      <div className="absolute inset-0 hero-gradient" />
      <div className="absolute inset-0 grid-bg opacity-20" />
      
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 text-center max-w-lg"
      >
        <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
          <Download className="w-8 h-8 text-white" />
        </div>

        <h1 className="text-4xl font-bold mb-4">
          <span className="text-gradient">Amber Labs</span>
          <br />
          Website Files
        </h1>
        
        <p className="text-text-secondary mb-8">
          Click the button below to download the complete website ZIP (37 KB).
          Then upload it to Vercel to deploy!
        </p>

        <a
          href="/amber-labs.tar.gz"
          download
          className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-primary to-accent text-white text-lg font-medium rounded-xl hover:shadow-xl hover:shadow-primary/25 transition-all hover:scale-105 active:scale-95"
        >
          <Download className="w-5 h-5" />
          Download Amber Labs ZIP
        </a>

        <p className="text-xs text-text-muted mt-4">
          ZIP file · 37 KB · Includes all source code
        </p>

        <div className="mt-12 glass rounded-2xl p-6 text-left text-sm text-text-secondary space-y-2">
          <p className="font-semibold text-text">📋 After downloading:</p>
          <p>1️⃣ Go to <span className="text-primary-light">vercel.com/new</span></p>
          <p>2️⃣ Upload the ZIP file</p>
          <p>3️⃣ Click <span className="text-accent-light">Deploy</span></p>
          <p className="text-success font-semibold pt-2">✅ Your site will be LIVE!</p>
        </div>

        <div className="mt-8 flex justify-center gap-4 text-text-muted text-xs">
          <span>📞 +91 9509672731</span>
          <span>✉️ devanshchotrani16@gmail.com</span>
        </div>
      </motion.div>
    </div>
  )
}
