'use client'

import { Sparkles, Heart } from 'lucide-react'
import { motion } from 'framer-motion'
import { siteConfig, services } from '@/lib/utils'

const footerLinks = {
  services: services.slice(0, 6).map(s => ({ label: s.title, href: `#${s.id}` })),
  company: [
    { label: 'About Us', href: '#about' },
    { label: 'Case Studies', href: '#case-studies' },
    { label: 'Blog', href: '#blog' },
    { label: 'Contact', href: '#contact' },
  ],
}

export default function Footer() {
  return (
    <footer className="relative pt-20 pb-8 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-[600px] bg-gradient-to-t from-primary/[0.02] to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="relative w-8 h-8">
                <div className="absolute inset-0 bg-gradient-to-br from-primary to-accent rounded-lg opacity-80" />
                <div className="absolute inset-0.5 bg-surface rounded-lg flex items-center justify-center">
                  <Sparkles className="w-3.5 h-3.5 text-primary-light" />
                </div>
              </div>
              <span className="font-bold text-lg">
                <span className="text-gradient">Amber</span>
                <span className="text-text-secondary ml-1">Labs</span>
              </span>
            </div>
            <p className="text-sm text-text-muted leading-relaxed mb-4">
              A cutting-edge digital innovation lab based in Jaipur, Rajasthan. We build premium websites, AI automation systems, and growth engines that scale businesses beyond imagination.
            </p>
            <div className="flex gap-3">
              {[
                { key: 'github', icon: 'G' },
                { key: 'linkedin', icon: 'in' },
                { key: 'whatsapp', icon: 'WA' },
              ].map((s) => (
                <a key={s.key} href={siteConfig.social[s.key as keyof typeof siteConfig.social]} target="_blank" rel="noopener noreferrer"
                  className="p-2 glass rounded-lg text-text-muted hover:text-text hover:bg-white/5 transition-all">
                  <span className="text-xs font-bold">{s.icon}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-sm font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              {footerLinks.services.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-text-muted hover:text-text transition-colors">{link.label}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-sm font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-text-muted hover:text-text transition-colors">{link.label}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-sm font-semibold mb-4">Stay Updated</h4>
            <p className="text-xs text-text-muted mb-3">Get marketing tips and case studies delivered to your inbox.</p>
            <form onSubmit={(e) => e.preventDefault()} className="flex gap-2">
              <input type="email" placeholder="your@email.com" className="input-premium flex-1 text-sm" />
              <button className="px-4 py-2 bg-gradient-to-r from-primary to-accent text-white text-sm rounded-lg hover:shadow-lg hover:shadow-primary/25 transition-all">
                Join
              </button>
            </form>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-text-muted">
            &copy; {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
          </p>
          <p className="text-xs text-text-muted flex items-center gap-1">
            Made with <Heart className="w-3 h-3 text-danger" /> in Jaipur, Rajasthan
          </p>
        </div>
      </div>
    </footer>
  )
}