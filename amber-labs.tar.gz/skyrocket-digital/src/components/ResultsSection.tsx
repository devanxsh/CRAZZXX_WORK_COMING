'use client'

import { useRef } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { TrendingUp, Users, BarChart3, Target, ArrowUp } from 'lucide-react'

const metrics = [
  { icon: BarChart3, value: '50M+', label: 'Ad Impressions', desc: 'Across Google & Meta platforms', gradient: 'from-primary to-accent' },
  { icon: TrendingUp, value: '500K+', label: 'Leads Generated', desc: 'Qualified prospects delivered', gradient: 'from-accent to-primary' },
  { icon: Users, value: '200+', label: 'Businesses Served', desc: 'Across 8+ industries', gradient: 'from-primary to-accent' },
  { icon: Target, value: '95%', label: 'Client Retention', desc: 'Industry-leading satisfaction', gradient: 'from-accent to-primary' },
]

function AnimatedCounter({ value }: { value: string }) {
  const num = parseInt(value.replace(/[^\d]/g, ''))
  const suffix = value.replace(/[\d]/g, '')
  
  return (
    <span className="text-4xl sm:text-5xl md:text-6xl font-bold text-gradient">
      {value}
    </span>
  )
}

export default function ResultsSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  })

  return (
    <section ref={sectionRef} className="relative py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/3 rounded-full blur-[200px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            Results That{' '}
            <span className="text-gradient">Speak Volumes</span>
          </h2>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto">
            Numbers don&apos;t lie. Here&apos;s the impact we&apos;ve delivered for businesses like yours.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {metrics.map((metric, i) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
              className="relative group"
            >
              <div className="glass rounded-2xl p-6 sm:p-8 text-center hover:bg-white/[0.04] transition-all duration-500">
                <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${metric.gradient} mb-4`}>
                  <metric.icon className="w-6 h-6 text-white" />
                </div>
                <AnimatedCounter value={metric.value} />
                <h3 className="text-lg font-semibold mt-2">{metric.label}</h3>
                <p className="text-sm text-text-muted mt-1">{metric.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <button
            onClick={() => document.getElementById('case-studies')?.scrollIntoView({ behavior: 'smooth' })}
            className="inline-flex items-center gap-2 text-text-secondary hover:text-text transition-colors group"
          >
            <span>View detailed case studies</span>
            <ArrowUp className="w-4 h-4 rotate-45 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </button>
        </motion.div>
      </div>
    </section>
  )
}