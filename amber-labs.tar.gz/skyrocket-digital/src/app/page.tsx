'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowUp } from 'lucide-react'
import Preloader from '@/components/Preloader'
import Navigation from '@/components/Navigation'
import Hero from '@/components/Hero'
import ServicesSection from '@/components/ServicesSection'
import ResultsSection from '@/components/ResultsSection'
import CaseStudiesSection from '@/components/CaseStudiesSection'
import ProcessSection from '@/components/ProcessSection'
import IndustriesSection from '@/components/IndustriesSection'
import TestimonialsSection from '@/components/TestimonialsSection'
import FAQSection from '@/components/FAQSection'
import ContactSection from '@/components/ContactSection'
import Footer from '@/components/Footer'

function ScrollToTop() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const toggle = () => setVisible(window.scrollY > 500)
    window.addEventListener('scroll', toggle, { passive: true })
    return () => window.removeEventListener('scroll', toggle)
  }, [])

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.5 }}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-8 right-8 z-40 p-3 glass-strong rounded-xl text-primary-light hover:text-text hover:bg-white/10 transition-all shadow-lg"
        >
          <ArrowUp className="w-5 h-5" />
        </motion.button>
      )}
    </AnimatePresence>
  )
}

export default function Home() {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2500)
    return () => clearTimeout(timer)
  }, [])

  return (
    <>
      {loading ? (
        <Preloader />
      ) : (
        <motion.main
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Navigation />
          <Hero />
          <ServicesSection />
          <ResultsSection />
          <CaseStudiesSection />
          <ProcessSection />
          <IndustriesSection />
          <TestimonialsSection />
          <FAQSection />
          <ContactSection />
          <Footer />
          <ScrollToTop />
        </motion.main>
      )}
    </>
  )
}