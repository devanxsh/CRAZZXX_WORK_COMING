import { MetadataRoute } from 'next'
import { siteConfig } from '@/lib/utils'

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = siteConfig.url
  const sections = ['', 'services', 'solutions', 'case-studies', 'about', 'blog', 'contact']
  
  return sections.map((section) => ({
    url: `${baseUrl}/${section}`,
    lastModified: new Date(),
    changeFrequency: section === '' ? 'weekly' : 'monthly',
    priority: section === '' ? 1.0 : 0.8,
  }))
}