'use client'

import { useState, useRef } from 'react'
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion'
import { ArrowRight, TrendingUp, Users, DollarSign, X, BarChart3, ExternalLink, ChevronRight } from 'lucide-react'
import { caseStudies } from '@/lib/utils'

function CaseStudyModal({ study, onClose }: { study: typeof caseStudies[0]; onClose: () => void }) {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          onClick={(e) => e.stopPropagation()}
          className="relative max-w-4xl w-full glass-strong rounded-2xl p-8 max-h-[85vh] overflow-y-auto"
        >
          <button onClick={onClose} className="absolute top-4 right-4 p-2 text-text-muted hover:text-text rounded-lg hover:bg-white/5 transition-colors">
            <X className="w-5 h-5" />
          </button>

          <div className="mb-6">
            <span className="text-xs text-accent-light font-semibold uppercase tracking-wider">{study.businessType}</span>
            <h3 className="text-2xl sm:text-3xl font-bold mt-1">{study.client}</h3>
          </div>

          {/* Challenge & Strategy */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="glass rounded-xl p-5">
              <h4 className="text-sm font-semibold text-text mb-3 uppercase tracking-wider flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-danger" />
                The Challenge
              </h4>
              <p className="text-sm text-text-secondary leading-relaxed">{study.challenge}</p>
            </div>
            <div className="glass rounded-xl p-5">
              <h4 className="text-sm font-semibold text-text mb-3 uppercase tracking-wider flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-success" />
                Our Strategy
              </h4>
              <p className="text-sm text-text-secondary leading-relaxed">{study.strategy}</p>
            </div>
          </div>

          {/* Results Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
            {[
              { label: 'Traffic Growth', value: study.results.trafficGrowth, icon: TrendingUp },
              { label: 'Lead Growth', value: study.results.leadGrowth, icon: Users },
              { label: 'Revenue Growth', value: study.results.revenueGrowth, icon: DollarSign },
              { label: 'Cost/Lead Reduced', value: study.results.costPerLead, icon: BarChart3 },
            ].map((r) => (
              <div key={r.label} className="glass rounded-xl p-4 text-center">
                <r.icon className="w-4 h-4 text-primary-light mx-auto mb-2" />
                <div className="text-xl font-bold text-gradient">{r.value}</div>
                <div className="text-xs text-text-muted">{r.label}</div>
              </div>
            ))}
          </div>

          {/* Before/After Table */}
          <div className="glass rounded-xl p-5 mb-6">
            <h4 className="text-sm font-semibold text-text mb-4 uppercase tracking-wider">Before & After Metrics</h4>
            <div className="space-y-3">
              {study.metrics.map((m) => (
                <div key={m.label} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02]">
                  <span className="text-sm text-text-secondary">{m.label}</span>
                  <div className="flex items-center gap-3 text-sm">
                    <span className="text-text-muted line-through">{m.before}</span>
                    <ChevronRight className="w-3 h-3 text-primary-light" />
                    <span className="text-success font-semibold">{m.after}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-6">
            {study.tags.map((tag) => (
              <span key={tag} className="px-3 py-1 text-xs glass rounded-full text-text-secondary">{tag}</span>
            ))}
          </div>

          <button
            onClick={() => { onClose(); document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }) }}
            className="w-full py-3 bg-gradient-to-r from-primary to-accent text-white font-medium rounded-xl hover:shadow-lg hover:shadow-primary/25 transition-all"
          >
            Get Results Like This — Book a Free Strategy Call
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

function CaseStudyCard({ study, index }: { study: typeof caseStudies[0]; index: number }) {
  const [hovered, setHovered] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: index * 0.1 }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={() => setModalOpen(true)}
        className="group cursor-pointer glass rounded-2xl overflow-hidden hover:bg-white/[0.04] transition-all duration-500"
      >
        {/* Image Area */}
        <div className="relative h-48 bg-gradient-to-br from-primary/10 via-accent/5 to-primary/10 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="text-lg font-bold text-gradient">{study.businessType}</div>
              <div className="text-sm text-text-muted mt-1">{study.client}</div>
            </div>
          </div>
          <div className={`absolute inset-0 bg-gradient-to-t from-surface/80 via-transparent to-transparent transition-opacity duration-500 ${hovered ? 'opacity-0' : 'opacity-100'}`} />
          <motion.div
            animate={{ scale: hovered ? 1.05 : 1 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 opacity-10"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(99,102,241,0.3) 0%, transparent 70%)',
            }}
          />
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="flex items-center gap-2 mb-3">
            {study.tags.slice(0, 2).map((tag) => (
              <span key={tag} className="px-2 py-0.5 text-xs glass rounded-full text-text-muted">{tag}</span>
            ))}
          </div>

          <h3 className="text-lg font-semibold mb-2 group-hover:text-gradient transition-all">{study.client}</h3>
          <p className="text-sm text-text-secondary leading-relaxed line-clamp-2 mb-4">{study.strategy}</p>

          {/* Preview Metrics */}
          <div className="grid grid-cols-3 gap-2 p-3 glass rounded-xl">
            <div className="text-center">
              <div className="text-sm font-bold text-success">{study.results.trafficGrowth}</div>
              <div className="text-xs text-text-muted">Traffic</div>
            </div>
            <div className="text-center">
              <div className="text-sm font-bold text-success">{study.results.leadGrowth}</div>
              <div className="text-xs text-text-muted">Leads</div>
            </div>
            <div className="text-center">
              <div className="text-sm font-bold text-success">{study.results.revenueGrowth}</div>
              <div className="text-xs text-text-muted">Revenue</div>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-1 text-sm text-primary-light opacity-0 group-hover:opacity-100 transition-opacity">
            <span>View full case study</span>
            <ExternalLink className="w-3 h-3" />
          </div>
        </div>
      </motion.div>

      {modalOpen && <CaseStudyModal study={study} onClose={() => setModalOpen(false)} />}
    </>
  )
}

export default function CaseStudiesSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  })

  return (
    <section id="case-studies" ref={sectionRef} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-20" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-strong mb-6"
          >
            <span className="w-2 h-2 rounded-full bg-success" />
            <span className="text-sm text-text-secondary">Proven Results</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6"
          >
            Real Results for{' '}
            <span className="text-gradient">Real Businesses</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-text-secondary text-lg max-w-2xl mx-auto"
          >
            See exactly how we transformed businesses across industries with data-driven strategies.
          </motion.p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {caseStudies.map((study, i) => (
            <CaseStudyCard key={study.id} study={study} index={i} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="group inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-primary to-accent text-white font-medium rounded-xl hover:shadow-xl hover:shadow-primary/25 transition-all hover:scale-105 active:scale-95"
          >
            Start Your Success Story
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>
    </section>
  )
}