'use client'

import { useRef } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { Search, BookOpen, Brain, Play, RefreshCw, TrendingUp } from 'lucide-react'

const steps = [
  { icon: Search, title: 'Discovery', desc: 'Deep dive into your business, market, competitors, and goals to build a complete picture.' },
  { icon: BookOpen, title: 'Research', desc: 'Data-driven market research, keyword analysis, audience profiling, and opportunity mapping.' },
  { icon: Brain, title: 'Strategy', desc: 'Custom roadmap combining SEO, paid ads, social media, automation, and content marketing.' },
  { icon: Play, title: 'Execution', desc: 'Meticulous implementation of every tactic with premium creatives and precision targeting.' },
  { icon: RefreshCw, title: 'Optimization', desc: 'Continuous A/B testing, data analysis, and refinement to maximize every rupee spent.' },
  { icon: TrendingUp, title: 'Scale', desc: 'Aggressive scaling of winning strategies across new channels, markets, and audiences.' },
]

export default function ProcessSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  })

  return (
    <section id="solutions" ref={sectionRef} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-strong mb-6"
          >
            <span className="w-2 h-2 rounded-full bg-accent" />
            <span className="text-sm text-text-secondary">Our Process</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl sm:text-5xl font-bold mb-6"
          >
            From Discovery to{' '}
            <span className="text-gradient">Domination</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-text-secondary max-w-2xl mx-auto"
          >
            Our proven 6-step process ensures every campaign is built on data, executed with precision, and optimized for maximum ROI.
          </motion.p>
        </div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-accent to-primary hidden md:block" />

          {/* Steps */}
          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative flex items-start gap-6 mb-8 last:mb-0 group"
            >
              {/* Dot */}
              <div className="relative z-10 flex-shrink-0 w-16 h-16 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                <step.icon className="w-6 h-6 text-primary-light" />
              </div>

              {/* Content */}
              <div className="glass rounded-2xl p-6 flex-1 group-hover:bg-white/[0.04] transition-colors">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-xs font-mono text-primary-light">0{i + 1}</span>
                  <h3 className="text-lg font-semibold">{step.title}</h3>
                </div>
                <p className="text-text-secondary text-sm leading-relaxed">{step.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}